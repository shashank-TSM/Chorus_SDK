//
//  Chorus_BLE_SDK.h
//  Chorus_BLE_SDK
//
//  Created by Shashank Gupta on 15/01/25.
//

#import <Foundation/Foundation.h>

//! Project version number for Chorus_BLE_SDK.
FOUNDATION_EXPORT double Chorus_BLE_SDKVersionNumber;

//! Project version string for Chorus_BLE_SDK.
FOUNDATION_EXPORT const unsigned char Chorus_BLE_SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Chorus_BLE_SDK/PublicHeader.h>


